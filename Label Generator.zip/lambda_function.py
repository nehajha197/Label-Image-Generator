import json
import boto3

s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    # Detect labels in the image
    response = rekognition.detect_labels(
        Image={
            'S3Object': {
                'Bucket': bucket,
                'Name': key,
            }
        }
    )

    labels = [label['Name'] for label in response['Labels']]

    # Upload labels as JSON file
    s3.put_object(
        Body=json.dumps(labels),
        Bucket='destination_bucket',
        Key=f'{key}_labels.json'
    )

    # Upload original image as JPG file
    s3.copy_object(
        Bucket='destination_bucket',
        Key=f'{key}.jpg',
        CopySource={'Bucket': bucket, 'Key': key}
    )

    return {
        'statusCode': 200,
        'body': json.dumps(labels)
    }
